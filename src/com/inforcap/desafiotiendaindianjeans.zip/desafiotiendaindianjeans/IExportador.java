package com.inforcap.desafiotiendaindianjeans;

public interface IExportador {

    void exportar();

}