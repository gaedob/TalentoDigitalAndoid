package com.inforcap.desafiotiendaindianjeans;

public abstract class Exportador  {

   
    public abstract void exportar();

}
