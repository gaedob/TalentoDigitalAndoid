package com.inforcap.desafiotiendaindianjeans;

public abstract class ExportarTxt {

    public void exportar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'exportar'");
    }



}
